import xbmc
import xbmcgui

dialog = xbmcgui.Dialog()
name = dialog.notification('Info', 'Hello World!')